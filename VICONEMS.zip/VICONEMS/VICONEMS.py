
from threading import*
import os
import sys
import time
from PyQt5.QtWidgets import *
from PyQt5 import QtGui
from PyQt5.QtMultimedia import QMediaContent, QMediaPlayer
from PyQt5.QtMultimediaWidgets import QVideoWidget
from PyQt5.Qt import QUrl
from PyQt5.QtGui import *
from tkinter import scrolledtext
from tkinter import*
import tkinter


def resource_path(relative_path):  # Relative paths of files
   try:
        base_path = sys._MEIPASS
   except Exception:
        base_path = os.path.abspath(".")
   return os.path.join(base_path, relative_path)
IconFilepath = resource_path("DataFiles/Icons/AI_Volved.ico")

if __name__ == "__main__":



    Aplication0 = QApplication(sys.argv)
    MainWindowGUI0 = QWidget()
    MainWindowGUI0.setFixedSize(450, 310)
    MainWindowGUI0.setWindowTitle('VICONEMS')
    MainWindowGUI0.setStyleSheet("background-color: white;")
    MainWindowGUI0.setStyleSheet("background-image: url(DataFiles/Icons/SplashScrn.jpg);");
    MainWindowGUI0.setWindowIcon(QtGui.QIcon(IconFilepath))
    MainWindowGUI0.show()
    Aplication0.setActiveWindow(MainWindowGUI0)
    QApplication.processEvents()
    time.sleep(3)




    Aplication = QApplication(sys.argv)
    MainWindowGUI = QWidget()
    MainWindowGUI.setFixedSize(1410, 820)
    MainWindowGUI.setWindowTitle('VICONEMS')
    MainWindowGUI.setStyleSheet("background-color: white;")
    MainWindowGUI.setStyleSheet("background-image: url(DataFiles/Icons/Wallpaper.jpg);");
    MainWindowGUI.setWindowIcon(QtGui.QIcon(IconFilepath))



    player1 = QMediaPlayer()
    wgt_video1 = QVideoWidget(MainWindowGUI)  # Video display widget
    wgt_video1.show()
    wgt_video1.setFixedSize(400, 260)
    wgt_video1.move(230, 100)
    player1.setVideoOutput(wgt_video1)  # widget for video output
    ChildVidPath = resource_path("DataFiles/Media/Child_Vid_Feed.avi")
    player1.setMedia(QMediaContent(
    QUrl.fromLocalFile(r"Child_Vid_Feed.avi")))  # Select video file



    player2 = QMediaPlayer()
    wgt_video2 = QVideoWidget(MainWindowGUI)  # Video display widget
    wgt_video2.show()
    wgt_video2.setFixedSize(500, 350)
    wgt_video2.move(855, 270)
    player2.setVideoOutput(wgt_video2)  # widget for video output
    ChildAnalysisPath = resource_path("DataFiles/Media/Child_Analysis_Vid.avi")
    player2.setMedia(QMediaContent(
    QUrl.fromLocalFile(r"Child_Analysis_Vid.avi")))  # Select video file


    player3 = QMediaPlayer()
    wgt_video3 = QVideoWidget(MainWindowGUI)  # Video display widget
    wgt_video3.show()
    wgt_video3.setFixedSize(400, 260)
    wgt_video3.move(230, 400)
    player3.setVideoOutput(wgt_video3)  # widget for video output
    SoundFeedpath = resource_path("DataFiles/Media/Sound_Feed.avi")
    player3.setMedia(QMediaContent(
    QUrl.fromLocalFile(r"Sound_Feed.avi")))  # Select video file


    def Render_AudSignal():
        time.sleep(10)
        QApplication.processEvents()
        player3.play()


    def Render_ChildVidLivSignal():
        QApplication.processEvents()
        player1.play()



    def Render_ChildAnlsSignal():
        QApplication.processEvents()
        player2.play()


    def displayResults():
        global Assessment1 ,Assessment2
        time.sleep(8)
        for i in range(0, 4):
            time.sleep(1)
            Assessment1.setText("Computing. ")
            Assessment2.setText("Computing..")
            QApplication.processEvents()
            time.sleep(1)
            Assessment1.setText("Computing.. ")
            Assessment2.setText("Computing...")
            QApplication.processEvents()
            time.sleep(1)
            Assessment1.setText("Computing... ")
            Assessment2.setText("Computing.")
            QApplication.processEvents()
            time.sleep(1)
            Assessment1.setText("Computing. ")
            Assessment2.setText("Computing..")
            QApplication.processEvents()

        Assessment1.setText("Low Risk")
        Assessment2.setText("Moderate")
        QApplication.processEvents()

    Task1 = Thread(target=Render_ChildVidLivSignal)  # Thread 1 object
    Task2 = Thread(target=Render_ChildAnlsSignal)  # Thread 2 object
    Task3 = Thread(target=Render_AudSignal)  # Thread 2 object
    Task4 = Thread(target=displayResults)  # Thread 2 object
    Task1.start()
    Task2.start()
    Task3.start()

    MainWindowGUI0.close()
    # AudioImage = resource_path("DataFiles/Media/AudioSignal.jpg")
    # pixmap = QtGui.QPixmap(AudioImage)
    # lABELimage = QLabel(MainWindowGUI)
    # lABELimage.setPixmap(pixmap)
    # lABELimage.setFixedSize(450, 300)
    # lABELimage.move(230, 450)
    # Render_AudSignal()
    label1 = QLabel(MainWindowGUI)
    label1.setText("Live Visual Feed")
    label1.setFont(QFont('segoe ui', 12))
    label1.setStyleSheet("color: black")
    label1.move(30 ,180)
    label1.show()

    label2 = QLabel(MainWindowGUI)
    label2.setText("Health Vitals Monitoring")
    label2.setFont(QFont('segoe ui', 12))
    label2.setStyleSheet("color: black")
    label2.move(850 ,220)
    label2.show()

    label3 = QLabel(MainWindowGUI)
    label3.setText("Audio Signal Feed")
    label3.setFont(QFont('segoe ui', 12))
    label3.setStyleSheet("color: black")
    label3.move(30 ,500)
    label3.show()

    label4 = QLabel(MainWindowGUI)
    label4.setText("Risk profile (HR/RL) : ")
    label4.setFont(QFont('segoe ui', 12))
    label4.setStyleSheet("color: black")
    label4.move(850 ,100)
    label4.show()


    label5 = QLabel(MainWindowGUI)
    label5.setText("Pain Scale ( Mild/Mod/High) : ")
    label5.setFont(QFont('segoe ui', 12))
    label5.setStyleSheet("color: black")
    label5.move(850 ,130)
    label5.show()

    Assessment1 = QLabel(MainWindowGUI)
    Assessment1.setText("Data Unavailabe")
    Assessment1.move(1150 ,80)
    Assessment1.setFont(QFont('segoe ui', 12))
    Assessment1.setStyleSheet("color: rgb(20, 114, 175)")
    Assessment1.resize(250, 50)
    Assessment1.show()

    Assessment2 = QLabel(MainWindowGUI)
    Assessment2.setText("Data Unavailabe")
    Assessment2.move(1150 ,120)
    Assessment2.setFont(QFont('segoe ui', 12))
    Assessment2.setStyleSheet("color: rgb(20, 114, 175)")
    Assessment2.resize(250, 50)
    Assessment2.show()

    Task4.start()



    MainWindowGUI.show()
    sys.exit(Aplication.exec_())
